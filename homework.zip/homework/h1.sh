#!/usr/bin/env bash

WorkDir=$(pwd)
#echo $WorkDir

csv="$WorkDir/res.csv"

echo "path,name,ext,sizi,per,created,modified,mime">"$csv"
echoToCSV(){
# 目录
#echo $1
pathDir=$1
c=0
#for file in $(ls "$1")
cd "$pathDir" || exit
for file in *;do
#  filelist[$c]=$file
  fullFile="$pathDir/$file"
#  echo $file
#  echo $fullFile
##  全名
#  echo "$WorkDir/$file"
## 文件名
#  echo $file
## 后缀名
#  echo "${file##*.}"
##  SIzi
#  echo $(stat -t "%Y-%m-%d" $file | awk '{print $8}')
##  权限
#  echo $( stat -t "%Y-%m-%d" $file| awk '{print $3}')
##  创建日期
#  echo "-"
##  修改日期
#  echo $(stat -t "%Y-%m-%d" $file | awk '{print $9}')
##  MIME
#  echo $(file -I $file  | awk '{print $2,$3}')


  if [ -d "$fullFile" ]; then
  echoToCSV "$fullFile"
#  echo "$fullFile is a directory "

elif [ -f "$fullFile" ]; then
 echo "$fullFile,$file,${file##*.},$(stat -t "%Y-%m-%d" "$fullFile" | \
  awk '{print $8}'),$( stat -t "%Y-%m-%d" "$fullFile"| awk '{print $3}'),-,$(stat -t "%Y-%m-%d" "$fullFile" | \
  awk '{print $9}'),$(file -I "$fullFile"  | awk '{print $2,$3}')" >> "$csv"
#  echo "$fullFile is a file"

fi

  ((c++))
done
}

echoToCSV "$WorkDir/test1"
