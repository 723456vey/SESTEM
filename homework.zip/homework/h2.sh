#!/usr/bin/env bash

workDir="$(pwd)/homework2"
#echo  $workDir
resp=("https://github.com/ipfs/go-ipfs"
"https://github.com/cjdelisle/cjdns"
"https://github.com/yggdrasil-network/yggdrasil-go"
"https://github.com/Bitmessage/PyBitmessage"
"https://github.com/popcorn-official/popcorn-desktop"
"https://github.com/andrejv/maxima"
"https://github.com/IntelRealSense/librealsense/tree/v1.12.1"
"https://github.com/mavlink/mavlink"
"https://github.com/ros/ros")
for  element  in "${resp[@]}"
do
splitTimes=$(echo "$element"|awk -F '/' '{print NF}')
if [ "$splitTimes" -gt 5 ]; then
    respName=$(echo "$element"|awk -F '/' '{print $(NF-2)}')
    version=$(echo "$element"|awk -F '/' '{print $NF}')
    element=$(echo "$element"|awk -F 'tree' '{print $1}')
    git clone -b "$version" "$element" "$workDir/$respName"

else
    respName=$(echo "$element"|awk -F '/' '{print $NF}')
    git clone "$element" "$workDir/$respName"

fi
done
